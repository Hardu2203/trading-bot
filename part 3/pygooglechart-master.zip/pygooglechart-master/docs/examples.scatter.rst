scatter Module
==============

.. automodule:: scatter
    :members:
    :undoc-members:
    :show-inheritance:
