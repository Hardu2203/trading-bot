Examples
========

.. toctree::
   :maxdepth: 2
   
   examples.all
   examples.bar
   examples.helper
   examples.labels
   examples.line
   examples.mapchart
   examples.pie
   examples.qrcodes
   examples.scatter
   examples.settings
   examples.venn

