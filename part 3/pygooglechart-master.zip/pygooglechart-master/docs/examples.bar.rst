bar Module
==========

.. automodule:: bar
    :members:
    :undoc-members:
    :show-inheritance:
