settings Module
===============

.. automodule:: settings
    :members:
    :undoc-members:
    :show-inheritance:
