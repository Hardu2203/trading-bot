pygooglechart Module
====================

.. automodule:: pygooglechart
    :members:
    :undoc-members:
    :show-inheritance:
