qrcodes Module
==============

.. automodule:: qrcodes
    :members:
    :undoc-members:
    :show-inheritance:
